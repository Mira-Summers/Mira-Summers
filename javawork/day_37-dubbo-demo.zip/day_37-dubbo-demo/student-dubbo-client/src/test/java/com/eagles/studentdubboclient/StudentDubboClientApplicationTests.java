package com.eagles.studentdubboclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDubboClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
