package com.dubbo.dubboservice;

import com.alibaba.dubbo.config.annotation.Service;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Service
class DubboServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
